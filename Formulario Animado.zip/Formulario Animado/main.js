//alert("carregoua a DOM");

document.body.onload = function(){


    const ulcubos = document.querySelector("ul.cubos")
    
    for(let i = 0; i < 20; i++){
        const li = document.createElement("li");

        const random = (min, max) => Math.random() * (max - min)      
    
        const tamanho = random(10, 120);
        const positio = random(1, 99);
        const dalay = random(5, 0.1);
        const duracao = random(24, 12);

        li.style.width = '90px';
        li.style.height = `90px`;
        li.style.bottom = `-${tamanho}px`;

        li.style.left = `${positio}%`;
        li.style.animationDelay = `${dalay}s`;
        li.style.animationDuration = `${duracao}s`
        li.style.animationTimingFunction = `cubic-bezier(${Math.random()}, ${Math.random()}, ${Math.random()}, ${Math.random()})`
        li.style.zIndex = '-1';


        ulcubos.appendChild(li);
    }


    //==============================================

    const form = document.querySelector("form");

    //dados do formulário
    const email = form.querySelector("#email");
    const pass = form.querySelector("#pass");

    document.querySelector("#btn-login").addEventListener("click", (e) => {
        e.preventDefault();

        console.log("clicado!");

        if(email.value !== '' && pass.value !== '' && pass.value.length >= 8){
            form.classList.add('formHide');
            form.classList.remove('erroData');
        }else{
            form.classList.remove('formHide');
            form.classList.add('erroData');
        }
    // verifica(email, pass, form);
        
    });

};
